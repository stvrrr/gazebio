'use client'

import { useState } from 'react'
import toast from 'react-hot-toast'

export function useClipboard(successMessage = 'Copied to clipboard!') {
  const [copied, setCopied] = useState(false)

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      toast.success(successMessage)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error('Failed to copy')
    }
  }

  return { copy, copied }
}
