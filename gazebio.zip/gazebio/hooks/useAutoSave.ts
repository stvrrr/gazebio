'use client'

import { useEffect, useRef } from 'react'

export function useAutoSave<T>(
  value: T,
  onSave: (value: T) => Promise<void>,
  delay = 800
) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const mountedRef = useRef(false)

  useEffect(() => {
    if (!mountedRef.current) {
      mountedRef.current = true
      return
    }

    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => {
      onSave(value).catch(console.error)
    }, delay)

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [value, delay]) // eslint-disable-line react-hooks/exhaustive-deps
}
