'use client'

import { useState, useCallback } from 'react'
import type { ProfileRow } from '@/lib/types'
import { updateProfile } from '@/lib/actions/profile'
import toast from 'react-hot-toast'

export function useProfile(initial: ProfileRow) {
  const [profile, setProfile] = useState<ProfileRow>(initial)
  const [saving, setSaving] = useState(false)

  const save = useCallback(
    async (updates: Partial<ProfileRow>) => {
      // Optimistic update
      setProfile(prev => ({ ...prev, ...updates }))
      setSaving(true)
      try {
        await updateProfile(updates as Parameters<typeof updateProfile>[0])
      } catch (err) {
        // Revert on failure
        setProfile(initial)
        toast.error('Failed to save changes')
      } finally {
        setSaving(false)
      }
    },
    [initial]
  )

  const patch = useCallback((updates: Partial<ProfileRow>) => {
    setProfile(prev => ({ ...prev, ...updates }))
  }, [])

  return { profile, setProfile, patch, save, saving }
}
