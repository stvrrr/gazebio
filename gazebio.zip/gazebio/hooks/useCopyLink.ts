'use client'

import { useCallback } from 'react'
import toast from 'react-hot-toast'

export function useCopyLink(username: string) {
  const copy = useCallback(() => {
    const url = `https://gazebio.vercel.app/${username}`
    navigator.clipboard
      .writeText(url)
      .then(() => toast.success('Link copied to clipboard!'))
      .catch(() => {
        // Fallback for browsers without clipboard API
        const el = document.createElement('textarea')
        el.value = url
        document.body.appendChild(el)
        el.select()
        document.execCommand('copy')
        document.body.removeChild(el)
        toast.success('Link copied!')
      })
  }, [username])

  return copy
}
