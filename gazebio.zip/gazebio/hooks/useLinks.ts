'use client'

import { useState, useCallback } from 'react'
import type { LinkRow } from '@/lib/types'
import { upsertLink, deleteLink, reorderLinks } from '@/lib/actions/profile'
import { ensureHttps } from '@/lib/utils'
import { nanoid } from 'nanoid'
import toast from 'react-hot-toast'

export function useLinks(initial: LinkRow[], profileId: string) {
  const [links, setLinks] = useState<LinkRow[]>(initial)

  const add = useCallback(
    async (title: string, url: string) => {
      const newLink: LinkRow = {
        id: nanoid(),
        profile_id: profileId,
        title: title.trim(),
        url: ensureHttps(url.trim()),
        clicks: 0,
        position: links.length,
        created_at: new Date().toISOString(),
      }
      setLinks(prev => [...prev, newLink])
      try {
        await upsertLink({
          id: newLink.id,
          profile_id: profileId,
          title: newLink.title,
          url: newLink.url,
          position: newLink.position,
        })
        toast.success('Link added!')
      } catch {
        setLinks(prev => prev.filter(l => l.id !== newLink.id))
        toast.error('Failed to add link')
      }
    },
    [links.length, profileId]
  )

  const remove = useCallback(
    async (id: string) => {
      const prev = links
      setLinks(l => l.filter(x => x.id !== id))
      try {
        await deleteLink(id)
        toast.success('Link removed')
      } catch {
        setLinks(prev)
        toast.error('Failed to delete link')
      }
    },
    [links]
  )

  const move = useCallback(
    async (id: string, dir: 'up' | 'down') => {
      const idx = links.findIndex(l => l.id === id)
      if (dir === 'up' && idx === 0) return
      if (dir === 'down' && idx === links.length - 1) return
      const arr = [...links]
      const swap = dir === 'up' ? idx - 1 : idx + 1
      ;[arr[idx], arr[swap]] = [arr[swap], arr[idx]]
      const reindexed = arr.map((l, i) => ({ ...l, position: i }))
      setLinks(reindexed)
      try {
        await reorderLinks(reindexed.map(l => ({ id: l.id, position: l.position })))
      } catch {
        setLinks(links)
        toast.error('Failed to reorder')
      }
    },
    [links]
  )

  const updateField = useCallback(
    (id: string, field: 'title' | 'url', value: string) => {
      setLinks(prev =>
        prev.map(l => (l.id === id ? { ...l, [field]: value } : l))
      )
    },
    []
  )

  const saveLink = useCallback(
    async (link: LinkRow) => {
      try {
        await upsertLink({
          id: link.id,
          profile_id: profileId,
          title: link.title,
          url: link.url,
          position: link.position,
        })
      } catch {
        toast.error('Failed to save link')
      }
    },
    [profileId]
  )

  return { links, add, remove, move, updateField, saveLink }
}
