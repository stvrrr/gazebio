-- ============================================================
-- GAZE BIOLINKS — Supabase Schema
-- Run this in your Supabase SQL editor at:
-- https://app.supabase.com/project/YOUR_PROJECT/sql/new
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── PROFILES ────────────────────────────────────────────────
create table if not exists public.profiles (
  id            uuid default uuid_generate_v4() primary key,
  user_id       uuid references auth.users(id) on delete cascade not null unique,
  username      text not null unique,
  display_name  text not null default '',
  bio           text not null default '',
  avatar_url    text,
  theme         text not null default 'Dark Modern',
  accent_color  text not null default '#00f5c4',
  font          text not null default 'DM Sans',
  btn_style     text not null default 'glass',
  total_views   integer not null default 0,
  created_at    timestamptz default now() not null,
  updated_at    timestamptz default now() not null,

  constraint username_length check (char_length(username) >= 2 and char_length(username) <= 30),
  constraint username_format check (username ~ '^[a-z0-9_]+$')
);

-- ── LINKS ───────────────────────────────────────────────────
create table if not exists public.links (
  id          uuid default uuid_generate_v4() primary key,
  profile_id  uuid references public.profiles(id) on delete cascade not null,
  title       text not null,
  url         text not null,
  clicks      integer not null default 0,
  position    integer not null default 0,
  created_at  timestamptz default now() not null
);

-- ── PROFILE STATS VIEW ───────────────────────────────────────
create or replace view public.profile_stats as
select
  p.id as profile_id,
  p.total_views,
  coalesce(sum(l.clicks), 0)::integer as total_clicks,
  count(l.id)::integer as link_count
from public.profiles p
left join public.links l on l.profile_id = p.id
group by p.id, p.total_views;

-- ── ROW LEVEL SECURITY ───────────────────────────────────────

alter table public.profiles enable row level security;
alter table public.links enable row level security;

-- Profiles: anyone can read, only owner can write
create policy "Public profiles are readable" on public.profiles
  for select using (true);

create policy "Users can insert own profile" on public.profiles
  for insert with check (auth.uid() = user_id);

create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = user_id);

-- Links: anyone can read, only profile owner can write
create policy "Public links are readable" on public.links
  for select using (true);

create policy "Profile owners can manage links" on public.links
  for all using (
    auth.uid() = (
      select user_id from public.profiles where id = profile_id
    )
  );

-- ── FUNCTIONS ────────────────────────────────────────────────

-- Auto-create profile on user signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (user_id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

-- Trigger for new user
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Increment link click count
create or replace function public.increment_link_click(link_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.links set clicks = clicks + 1 where id = link_id;
end;
$$;

-- Increment profile view count
create or replace function public.increment_profile_view(profile_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.profiles set total_views = total_views + 1 where id = profile_id;
end;
$$;

-- ── INDEXES ──────────────────────────────────────────────────
create index if not exists idx_profiles_username on public.profiles(username);
create index if not exists idx_profiles_user_id on public.profiles(user_id);
create index if not exists idx_links_profile_id on public.links(profile_id);
create index if not exists idx_links_position on public.links(profile_id, position);

-- ── STORAGE ──────────────────────────────────────────────────
-- Create an 'avatars' bucket (run manually in Supabase dashboard or here)
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict do nothing;

-- Allow authenticated users to upload avatars
create policy "Authenticated users can upload avatars" on storage.objects
  for insert with check (bucket_id = 'avatars' and auth.role() = 'authenticated');

create policy "Anyone can read avatars" on storage.objects
  for select using (bucket_id = 'avatars');

create policy "Users can update own avatar" on storage.objects
  for update using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Users can delete own avatar" on storage.objects
  for delete using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
