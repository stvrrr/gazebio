import type { ThemeName, ButtonStyle, FontName } from './types'

export interface ThemeConfig {
  id: string
  name: ThemeName
  bg: string
  card: string
  border: string
  text: string
  sub: string
  accent: string
  btnStyle: ButtonStyle
  font: FontName
  preview: [string, string, string]
  isLight?: boolean
}

export const THEMES: Record<ThemeName, ThemeConfig> = {
  'Dark Modern': {
    id: 'dark-modern',
    name: 'Dark Modern',
    bg: 'linear-gradient(135deg, #070710 0%, #0e0e1f 100%)',
    card: 'rgba(255,255,255,0.05)',
    border: 'rgba(255,255,255,0.08)',
    text: '#e8eaf6',
    sub: '#7b7fa3',
    accent: '#00f5c4',
    btnStyle: 'glass',
    font: 'DM Sans',
    preview: ['#070710', '#00f5c4', '#0e0e1f'],
  },
  'Neon Gamer': {
    id: 'neon-gamer',
    name: 'Neon Gamer',
    bg: 'linear-gradient(160deg, #050510 0%, #0a0520 50%, #050510 100%)',
    card: 'rgba(0,245,196,0.04)',
    border: 'rgba(0,245,196,0.15)',
    text: '#e0fff8',
    sub: '#4ecdc4',
    accent: '#00f5c4',
    btnStyle: 'glow',
    font: 'Orbitron',
    preview: ['#050510', '#00f5c4', '#7c3aed'],
  },
  'Cyberpunk Glow': {
    id: 'cyberpunk-glow',
    name: 'Cyberpunk Glow',
    bg: 'linear-gradient(135deg, #0a0005 0%, #1a0010 50%, #0a0005 100%)',
    card: 'rgba(255,0,128,0.04)',
    border: 'rgba(255,0,128,0.18)',
    text: '#fff0f8',
    sub: '#c084a0',
    accent: '#ff007f',
    btnStyle: 'glow',
    font: 'Orbitron',
    preview: ['#0a0005', '#ff007f', '#ffcc00'],
  },
  'Soft Aesthetic': {
    id: 'soft-aesthetic',
    name: 'Soft Aesthetic',
    bg: 'linear-gradient(135deg, #1a0f1f 0%, #0f1a2e 100%)',
    card: 'rgba(255,200,255,0.05)',
    border: 'rgba(200,150,255,0.15)',
    text: '#f0e8ff',
    sub: '#9b8ab0',
    accent: '#c084fc',
    btnStyle: 'pill',
    font: 'Playfair Display',
    preview: ['#1a0f1f', '#c084fc', '#f0abfc'],
  },
  'Gradient Glass': {
    id: 'gradient-glass',
    name: 'Gradient Glass',
    bg: 'linear-gradient(135deg, #0a1628 0%, #0d2137 50%, #0a1628 100%)',
    card: 'rgba(100,200,255,0.05)',
    border: 'rgba(100,200,255,0.12)',
    text: '#e0f4ff',
    sub: '#6a9ab8',
    accent: '#38bdf8',
    btnStyle: 'glass',
    font: 'Syne',
    preview: ['#0a1628', '#38bdf8', '#818cf8'],
  },
  'Minimal Light': {
    id: 'minimal-light',
    name: 'Minimal Light',
    bg: 'linear-gradient(135deg, #f0f4ff 0%, #e8eeff 100%)',
    card: 'rgba(255,255,255,0.7)',
    border: 'rgba(0,0,0,0.08)',
    text: '#1a1a2e',
    sub: '#6b7280',
    accent: '#6c63ff',
    btnStyle: 'rounded',
    font: 'Syne',
    preview: ['#f0f4ff', '#6c63ff', '#ffffff'],
    isLight: true,
  },
}

export const BUTTON_STYLES: Record<ButtonStyle, React.CSSProperties> = {
  rounded: { borderRadius: '12px' },
  pill: { borderRadius: '999px' },
  glow: { borderRadius: '10px' },
  glass: { borderRadius: '12px', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)' },
}

export const FONTS: FontName[] = [
  'DM Sans',
  'Syne',
  'Orbitron',
  'Playfair Display',
  'JetBrains Mono',
]

export const FONT_CSS_MAP: Record<FontName, string> = {
  'DM Sans': "'DM Sans', sans-serif",
  'Syne': "'Syne', sans-serif",
  'Orbitron': "'Orbitron', sans-serif",
  'Playfair Display': "'Playfair Display', serif",
  'JetBrains Mono': "'JetBrains Mono', monospace",
}

export function getTheme(name: string): ThemeConfig {
  return THEMES[name as ThemeName] ?? THEMES['Dark Modern']
}
