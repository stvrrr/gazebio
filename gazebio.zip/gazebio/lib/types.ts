export type ButtonStyle = 'rounded' | 'pill' | 'glow' | 'glass'

export type ThemeName =
  | 'Dark Modern'
  | 'Neon Gamer'
  | 'Cyberpunk Glow'
  | 'Soft Aesthetic'
  | 'Gradient Glass'
  | 'Minimal Light'

export type FontName =
  | 'DM Sans'
  | 'Syne'
  | 'Orbitron'
  | 'Playfair Display'
  | 'JetBrains Mono'

export interface GazeLink {
  id: string
  title: string
  url: string
  clicks: number
  position: number
}

export interface GazeProfile {
  id: string
  user_id: string
  username: string
  display_name: string
  bio: string
  avatar_url: string | null
  theme: ThemeName
  accent_color: string
  font: FontName
  btn_style: ButtonStyle
  created_at: string
  updated_at: string
}

export interface GazeStats {
  total_views: number
  total_clicks: number
  link_count: number
}

// Supabase DB row shapes (snake_case mirrors DB columns)
export interface ProfileRow {
  id: string
  user_id: string
  username: string
  display_name: string
  bio: string
  avatar_url: string | null
  theme: string
  accent_color: string
  font: string
  btn_style: string
  created_at: string
  updated_at: string
}

export interface LinkRow {
  id: string
  profile_id: string
  title: string
  url: string
  clicks: number
  position: number
  created_at: string
}
