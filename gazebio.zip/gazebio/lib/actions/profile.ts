'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'
import type { ThemeName, ButtonStyle, FontName } from '@/lib/types'

export async function getProfile() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', user.id)
    .single()

  return data
}

export async function getProfileByUsername(username: string) {
  const supabase = createClient()
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', username)
    .single()
  return data
}

export async function getLinks(profileId: string) {
  const supabase = createClient()
  const { data } = await supabase
    .from('links')
    .select('*')
    .eq('profile_id', profileId)
    .order('position', { ascending: true })
  return data ?? []
}

export async function updateProfile(updates: {
  display_name?: string
  bio?: string
  username?: string
  theme?: ThemeName
  accent_color?: string
  font?: FontName
  btn_style?: ButtonStyle
}) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error('Not authenticated')

  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_id', user.id)

  if (error) throw error
  revalidatePath('/dashboard')
  revalidatePath('/editor')
}

export async function upsertLink(link: {
  id?: string
  profile_id: string
  title: string
  url: string
  position: number
}) {
  const supabase = createClient()
  const { error } = await supabase.from('links').upsert(link)
  if (error) throw error
  revalidatePath('/editor')
}

export async function deleteLink(id: string) {
  const supabase = createClient()
  const { error } = await supabase.from('links').delete().eq('id', id)
  if (error) throw error
  revalidatePath('/editor')
}

export async function reorderLinks(links: { id: string; position: number }[]) {
  const supabase = createClient()
  const updates = links.map(({ id, position }) =>
    supabase.from('links').update({ position }).eq('id', id)
  )
  await Promise.all(updates)
  revalidatePath('/editor')
}

export async function incrementLinkClick(linkId: string) {
  const supabase = createClient()
  await supabase.rpc('increment_link_click', { link_id: linkId })
}

export async function incrementProfileView(profileId: string) {
  const supabase = createClient()
  await supabase.rpc('increment_profile_view', { profile_id: profileId })
}

export async function getProfileStats(profileId: string) {
  const supabase = createClient()
  const { data } = await supabase
    .from('profile_stats')
    .select('*')
    .eq('profile_id', profileId)
    .single()
  return data
}

export async function isUsernameAvailable(username: string): Promise<boolean> {
  const supabase = createClient()
  const { data } = await supabase
    .from('profiles')
    .select('id')
    .eq('username', username)
    .single()
  return !data
}
