'use client'

import { useState } from 'react'
import type { ProfileRow, LinkRow } from '@/lib/types'
import { getTheme, BUTTON_STYLES, FONT_CSS_MAP } from '@/lib/themes'
import { getInitials } from '@/lib/utils'
import { incrementLinkClick } from '@/lib/actions/profile'
import { ExternalIcon } from '@/components/ui/Icon'

interface Props {
  profile: ProfileRow
  links: LinkRow[]
  isPreview?: boolean
}

export default function PublicProfile({ profile, links, isPreview = false }: Props) {
  const theme = getTheme(profile.theme)
  const btnStyleCSS = BUTTON_STYLES[profile.btn_style] ?? BUTTON_STYLES.glass
  const fontCSS = FONT_CSS_MAP[profile.font as keyof typeof FONT_CSS_MAP] ?? FONT_CSS_MAP['DM Sans']
  const [hoveredLink, setHoveredLink] = useState<string | null>(null)
  const [clickedLinks, setClickedLinks] = useState<Set<string>>(new Set())

  const handleLinkClick = (link: LinkRow) => {
    if (!isPreview && !clickedLinks.has(link.id)) {
      setClickedLinks(prev => new Set([...prev, link.id]))
      incrementLinkClick(link.id).catch(() => {})
    }
  }

  const initials = getInitials(profile.display_name || profile.username)

  return (
    <div
      style={{
        minHeight: isPreview ? 'auto' : '100vh',
        background: theme.bg,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '48px 20px 64px',
        fontFamily: fontCSS,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Ambient orb */}
      <div
        style={{
          position: 'absolute',
          top: '5%',
          left: '50%',
          transform: 'translateX(-50%)',
          width: 320,
          height: 320,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${profile.accent_color}20 0%, transparent 70%)`,
          pointerEvents: 'none',
          animation: 'orb1 14s ease-in-out infinite',
        }}
      />

      <div
        style={{
          width: '100%',
          maxWidth: 400,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {/* Avatar */}
        <div style={{ animation: 'fadeUp 0.5s ease both', marginBottom: 16 }}>
          <div
            style={{
              width: 88,
              height: 88,
              borderRadius: '50%',
              background: `radial-gradient(circle, ${profile.accent_color}30, ${profile.accent_color}10)`,
              border: `2.5px solid ${profile.accent_color}60`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 32px ${profile.accent_color}30, 0 0 80px ${profile.accent_color}15`,
              animation: 'float 6s ease-in-out infinite',
              fontSize: 28,
              fontWeight: 800,
              color: profile.accent_color,
              userSelect: 'none',
            }}
          >
            {initials}
          </div>
        </div>

        {/* Display name */}
        <h1
          style={{
            fontFamily: fontCSS,
            fontWeight: 800,
            fontSize: 22,
            letterSpacing: '-0.02em',
            color: theme.isLight ? '#1a1a2e' : '#e8eaf6',
            animation: 'fadeUp 0.5s ease 0.1s both',
            textAlign: 'center',
            margin: 0,
          }}
        >
          {profile.display_name || profile.username}
        </h1>

        {/* @username */}
        <div
          style={{
            fontSize: 13,
            color: profile.accent_color,
            marginTop: 4,
            fontFamily: 'var(--font-jetbrains, monospace)',
            animation: 'fadeUp 0.5s ease 0.15s both',
          }}
        >
          @{profile.username}
        </div>

        {/* Bio */}
        {profile.bio && (
          <p
            style={{
              fontSize: 14,
              lineHeight: 1.65,
              textAlign: 'center',
              color: theme.isLight ? '#4a4a6a' : theme.sub,
              marginTop: 12,
              maxWidth: 320,
              animation: 'fadeUp 0.5s ease 0.2s both',
            }}
          >
            {profile.bio}
          </p>
        )}

        <div
          style={{
            width: '60%',
            height: 1,
            background: `${profile.accent_color}20`,
            margin: '24px 0',
          }}
        />

        {/* Links */}
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {links.map((link, i) => {
            const isHovered = hoveredLink === link.id
            const isGlow = profile.btn_style === 'glow'

            return (
              <a
                key={link.id}
                href={isPreview ? '#' : link.url}
                target={isPreview ? undefined : '_blank'}
                rel="noopener noreferrer"
                onClick={() => handleLinkClick(link)}
                onMouseEnter={() => setHoveredLink(link.id)}
                onMouseLeave={() => setHoveredLink(null)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '15px 20px',
                  background: isHovered
                    ? theme.isLight ? 'rgba(255,255,255,0.9)' : theme.card.replace('0.05', '0.12').replace('0.04', '0.1')
                    : theme.isLight ? 'rgba(255,255,255,0.7)' : theme.card,
                  border: `1px solid ${isHovered ? profile.accent_color + '50' : theme.border}`,
                  color: theme.text,
                  textDecoration: 'none',
                  transform: isHovered ? 'translateY(-2px) scale(1.01)' : 'translateY(0) scale(1)',
                  boxShadow: isHovered
                    ? isGlow
                      ? `0 0 24px ${profile.accent_color}50, 0 8px 24px rgba(0,0,0,0.3)`
                      : '0 8px 24px rgba(0,0,0,0.3)'
                    : 'none',
                  transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)',
                  animation: `fadeUp 0.5s ease ${0.25 + i * 0.07}s both`,
                  backdropFilter: 'blur(12px)',
                  WebkitBackdropFilter: 'blur(12px)',
                  cursor: 'pointer',
                  ...btnStyleCSS,
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 600, fontFamily: fontCSS }}>{link.title}</span>
                <ExternalIcon size={14} color={isHovered ? profile.accent_color : theme.sub} />
              </a>
            )
          })}

          {links.length === 0 && !isPreview && (
            <p style={{ textAlign: 'center', color: theme.sub, fontSize: 14 }}>
              No links yet.
            </p>
          )}
        </div>

        {/* Gaze branding */}
        <div style={{ marginTop: 44, animation: 'fadeUp 0.5s ease 0.6s both' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, opacity: 0.4 }}>
            <div style={{ width: 14, height: 14, borderRadius: '50%', background: `linear-gradient(135deg, ${profile.accent_color}, #00c4f5)`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <div style={{ width: '40%', height: '40%', borderRadius: '50%', background: '#070710', margin: '30%' }} />
            </div>
            <span style={{ fontSize: 11, fontFamily: 'var(--font-syne, sans-serif)', fontWeight: 700, color: theme.isLight ? '#1a1a2e' : '#e8eaf6' }}>
              gaze<span style={{ color: profile.accent_color }}>.</span>bio
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
