'use client'

import { useRef, useState } from 'react'
import toast from 'react-hot-toast'
import { Avatar } from '@/components/ui/Avatar'
import { CameraIcon } from '@/components/ui/Icon'

interface Props {
  name: string
  accentColor: string
  avatarUrl: string | null
  onUploaded: (url: string) => void
}

export function AvatarUpload({ name, accentColor, avatarUrl, onUploaded }: Props) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)

  const upload = async (file: File) => {
    setUploading(true)
    const formData = new FormData()
    formData.append('avatar', file)

    try {
      const res = await fetch('/api/avatar', { method: 'POST', body: formData })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error ?? 'Upload failed')
      onUploaded(json.url)
      toast.success('Avatar updated!')
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Upload failed'
      toast.error(msg)
    } finally {
      setUploading(false)
    }
  }

  const handleFile = (file: File | null | undefined) => {
    if (!file) return
    upload(file)
  }

  return (
    <div className="text-center">
      <div
        className="relative inline-block cursor-pointer"
        onClick={() => inputRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={e => {
          e.preventDefault()
          setDragOver(false)
          handleFile(e.dataTransfer.files[0])
        }}
        style={{
          outline: dragOver ? `2px dashed ${accentColor}` : '2px dashed transparent',
          borderRadius: '50%',
          transition: 'outline 0.2s',
        }}
      >
        <Avatar
          name={name}
          accentColor={accentColor}
          avatarUrl={avatarUrl}
          size={72}
        />

        {/* Overlay on hover */}
        <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
          {uploading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <CameraIcon size={18} color="white" />
          )}
        </div>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        className="hidden"
        onChange={e => handleFile(e.target.files?.[0])}
      />

      <p className="text-[11px] text-[var(--sub)] mt-2">
        {uploading ? 'Uploading…' : 'Click or drag to upload · Max 2MB'}
      </p>
    </div>
  )
}
