'use client'

import Link from 'next/link'
import type { ProfileRow, LinkRow } from '@/lib/types'
import PublicProfile from '@/components/profile/PublicProfile'
import { EditIcon } from '@/components/ui/Icon'

interface Props {
  profile: ProfileRow
  links: LinkRow[]
}

export default function PreviewView({ profile, links }: Props) {
  return (
    <div className="py-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h2 className="font-syne text-xl font-black tracking-tight text-[var(--text)]">
            Live Preview
          </h2>
          <p className="text-[13px] text-[var(--sub)] mt-0.5">
            Exactly what visitors see at{' '}
            <span className="text-[var(--accent)] font-mono">
              gazebio.vercel.app/{profile.username}
            </span>
          </p>
        </div>
        <Link
          href="/editor"
          className="flex items-center gap-2 px-4 py-2 rounded-[10px] bg-gradient-to-r from-accent to-[#00c4f5] text-[#020c0a] text-[13px] font-semibold hover:shadow-[0_0_24px_rgba(0,245,196,0.35)] hover:-translate-y-px transition-all"
        >
          <EditIcon size={14} color="#020c0a" />
          Edit Page
        </Link>
      </div>

      {/* Device frame */}
      <div className="max-w-[420px] mx-auto">
        {/* Browser chrome */}
        <div className="glass-card rounded-b-none border-b-0 px-4 py-3 flex items-center gap-3">
          <div className="flex gap-1.5">
            {['#ff5f57', '#febc2e', '#28c840'].map((c) => (
              <div
                key={c}
                style={{ width: 11, height: 11, borderRadius: '50%', background: c }}
              />
            ))}
          </div>
          <div className="flex-1 bg-white/[0.05] rounded-md px-3 py-1.5 text-[12px] text-[var(--sub)] font-mono">
            gazebio.vercel.app/
            <span className="text-[var(--accent)]">{profile.username}</span>
          </div>
        </div>

        {/* Profile content inside frame */}
        <div
          className="rounded-b-[18px] overflow-hidden border border-t-0 border-[var(--glass-border)]"
          style={{ boxShadow: '0 24px 80px rgba(0,0,0,0.5)' }}
        >
          <PublicProfile profile={profile} links={links} isPreview />
        </div>
      </div>

      {/* Share section */}
      <div className="max-w-[420px] mx-auto mt-6">
        <div className="glass-card p-5 text-center">
          <p className="text-[13px] text-[var(--sub)] mb-3">
            Share your page with the world
          </p>
          <div className="flex items-center gap-2 bg-white/[0.04] rounded-lg px-3 py-2.5 border border-[var(--glass-border)]">
            <span className="flex-1 text-[13px] font-mono text-[var(--text)] text-left truncate">
              https://gazebio.vercel.app/{profile.username}
            </span>
            <button
              onClick={() =>
                navigator.clipboard
                  ?.writeText(`https://gazebio.vercel.app/${profile.username}`)
                  .catch(() => {})
              }
              className="text-[12px] text-[var(--accent)] font-semibold hover:underline whitespace-nowrap"
            >
              Copy
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
