'use client'

import { useState, useCallback, useTransition } from 'react'
import toast from 'react-hot-toast'
import type { ProfileRow, LinkRow, ThemeName, FontName, ButtonStyle } from '@/lib/types'
import { updateProfile, upsertLink, deleteLink, reorderLinks } from '@/lib/actions/profile'
import { THEMES, FONTS, BUTTON_STYLES } from '@/lib/themes'
import { slugify, ensureHttps } from '@/lib/utils'
import { Avatar } from '@/components/ui/Avatar'
import {
  UserIcon, LinkIcon, PaletteIcon, PlusIcon, TrashIcon,
  ChevronUpIcon, ChevronDownIcon, CheckIcon,
} from '@/components/ui/Icon'
import PublicProfile from '@/components/profile/PublicProfile'
import { nanoid } from 'nanoid'

interface Props {
  profile: ProfileRow
  links: LinkRow[]
}

type EditorTab = 'profile' | 'links' | 'design'

// Local optimistic types
type LocalProfile = ProfileRow
type LocalLink = LinkRow & { _isNew?: boolean }

export default function EditorView({ profile: initialProfile, links: initialLinks }: Props) {
  const [profile, setProfile] = useState<LocalProfile>(initialProfile)
  const [links, setLinks] = useState<LocalLink[]>(initialLinks)
  const [tab, setTab] = useState<EditorTab>('profile')
  const [isPending, startTransition] = useTransition()
  const [newLink, setNewLink] = useState({ title: '', url: '' })
  const [showNewLink, setShowNewLink] = useState(false)
  const [savingField, setSavingField] = useState<string | null>(null)

  const saveProfile = useCallback(async (updates: Partial<LocalProfile>) => {
    setProfile(p => ({ ...p, ...updates }))
    setSavingField(Object.keys(updates)[0])
    try {
      await updateProfile(updates as Parameters<typeof updateProfile>[0])
    } catch {
      toast.error('Failed to save — try again')
    } finally {
      setSavingField(null)
    }
  }, [])

  const handleAddLink = async () => {
    if (!newLink.title.trim() || !newLink.url.trim()) {
      toast.error('Please fill in both title and URL')
      return
    }
    const url = ensureHttps(newLink.url.trim())
    const newItem: LocalLink = {
      id: nanoid(),
      profile_id: profile.id,
      title: newLink.title.trim(),
      url,
      clicks: 0,
      position: links.length,
      created_at: new Date().toISOString(),
      _isNew: true,
    }
    setLinks(prev => [...prev, newItem])
    setNewLink({ title: '', url: '' })
    setShowNewLink(false)

    try {
      await upsertLink({
        id: newItem.id,
        profile_id: profile.id,
        title: newItem.title,
        url: newItem.url,
        position: newItem.position,
      })
      toast.success('Link added!')
    } catch {
      setLinks(prev => prev.filter(l => l.id !== newItem.id))
      toast.error('Failed to add link')
    }
  }

  const handleDeleteLink = async (id: string) => {
    const prev = [...links]
    setLinks(l => l.filter(x => x.id !== id))
    try {
      await deleteLink(id)
      toast.success('Link removed')
    } catch {
      setLinks(prev)
      toast.error('Failed to delete link')
    }
  }

  const handleMoveLink = async (id: string, dir: 'up' | 'down') => {
    const idx = links.findIndex(l => l.id === id)
    if (dir === 'up' && idx === 0) return
    if (dir === 'down' && idx === links.length - 1) return
    const arr = [...links]
    const swap = dir === 'up' ? idx - 1 : idx + 1
    ;[arr[idx], arr[swap]] = [arr[swap], arr[idx]]
    const reindexed = arr.map((l, i) => ({ ...l, position: i }))
    setLinks(reindexed)
    try {
      await reorderLinks(reindexed.map(l => ({ id: l.id, position: l.position })))
    } catch {
      setLinks(links)
      toast.error('Failed to reorder')
    }
  }

  const handleUpdateLink = async (id: string, field: 'title' | 'url', val: string) => {
    setLinks(prev => prev.map(l => l.id === id ? { ...l, [field]: val } : l))
  }

  const handleBlurLink = async (link: LocalLink) => {
    try {
      await upsertLink({
        id: link.id,
        profile_id: profile.id,
        title: link.title,
        url: link.url,
        position: link.position,
      })
    } catch {
      toast.error('Failed to save link')
    }
  }

  const TABS: { id: EditorTab; label: string; Icon: React.ElementType }[] = [
    { id: 'profile', label: 'Profile', Icon: UserIcon },
    { id: 'links', label: 'Links', Icon: LinkIcon },
    { id: 'design', label: 'Design', Icon: PaletteIcon },
  ]

  return (
    <div className="flex h-[calc(100vh-60px)] overflow-hidden">
      {/* ── LEFT PANEL ─────────────────────────────────────────── */}
      <div className="w-[380px] flex-shrink-0 border-r border-[var(--glass-border)] flex flex-col overflow-hidden">
        {/* Tab bar */}
        <div className="flex border-b border-[var(--glass-border)] px-4 pt-4">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className="flex items-center gap-1.5 px-3.5 pb-3 border-b-2 text-[13px] font-semibold transition-colors mr-1"
              style={{
                color: tab === id ? 'var(--accent)' : 'var(--sub)',
                borderBottomColor: tab === id ? 'var(--accent)' : 'transparent',
                marginBottom: -1,
              }}
            >
              <Icon size={14} color={tab === id ? 'var(--accent)' : 'var(--sub)'} />
              {label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* ── PROFILE TAB ─── */}
          {tab === 'profile' && (
            <div className="space-y-5 animate-fade-in">
              <div className="text-center pt-2">
                <Avatar
                  name={profile.display_name || profile.username}
                  accentColor={profile.accent_color}
                  avatarUrl={profile.avatar_url}
                  size={72}
                  showCamera
                />
                <p className="text-[11px] text-[var(--sub)] mt-2">Avatar upload coming soon</p>
              </div>

              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">Display Name</label>
                <input
                  className="gaze-input"
                  value={profile.display_name}
                  placeholder="Your Name"
                  onChange={e => setProfile(p => ({ ...p, display_name: e.target.value }))}
                  onBlur={() => saveProfile({ display_name: profile.display_name })}
                />
              </div>

              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">Username</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--sub)] text-[13px] pointer-events-none select-none">
                    gazebio.vercel.app/
                  </span>
                  <input
                    className="gaze-input"
                    style={{ paddingLeft: 174 }}
                    value={profile.username}
                    onChange={e => setProfile(p => ({ ...p, username: slugify(e.target.value) }))}
                    onBlur={() => saveProfile({ username: profile.username })}
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">Bio</label>
                <textarea
                  className="gaze-input resize-none leading-relaxed"
                  rows={3}
                  value={profile.bio}
                  placeholder="Tell the world who you are..."
                  onChange={e => setProfile(p => ({ ...p, bio: e.target.value }))}
                  onBlur={() => saveProfile({ bio: profile.bio })}
                />
              </div>
            </div>
          )}

          {/* ── LINKS TAB ─── */}
          {tab === 'links' && (
            <div className="space-y-3 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-[13px] text-[var(--sub)]">{links.length} link{links.length !== 1 ? 's' : ''}</span>
                <button
                  onClick={() => setShowNewLink(!showNewLink)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-accent to-[#00c4f5] text-[#020c0a] text-[13px] font-semibold hover:shadow-[0_0_20px_rgba(0,245,196,0.3)] hover:-translate-y-px transition-all"
                >
                  <PlusIcon size={13} color="#020c0a" /> Add Link
                </button>
              </div>

              {showNewLink && (
                <div className="glass-card p-4 border-[rgba(0,245,196,0.2)] animate-fade-up space-y-2.5">
                  <input
                    className="gaze-input text-[13px]"
                    placeholder="Link title"
                    value={newLink.title}
                    onChange={e => setNewLink(p => ({ ...p, title: e.target.value }))}
                    autoFocus
                  />
                  <input
                    className="gaze-input text-[13px]"
                    placeholder="https://..."
                    value={newLink.url}
                    onChange={e => setNewLink(p => ({ ...p, url: e.target.value }))}
                    onKeyDown={e => e.key === 'Enter' && handleAddLink()}
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleAddLink}
                      className="flex-1 py-2 rounded-lg bg-gradient-to-r from-accent to-[#00c4f5] text-[#020c0a] text-[13px] font-semibold transition-all hover:-translate-y-px"
                    >
                      Add
                    </button>
                    <button
                      onClick={() => { setShowNewLink(false); setNewLink({ title: '', url: '' }) }}
                      className="px-4 py-2 rounded-lg bg-[var(--glass)] border border-[var(--glass-border)] text-[13px] text-[var(--text)] hover:bg-[var(--glass-hover)] transition-all"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {links.map((link, i) => (
                <div key={link.id} className="glass-card p-3.5 space-y-2.5">
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col gap-0.5">
                      <button onClick={() => handleMoveLink(link.id, 'up')} className="p-1 rounded hover:bg-white/[0.08] transition-colors">
                        <ChevronUpIcon size={11} color="var(--sub)" />
                      </button>
                      <button onClick={() => handleMoveLink(link.id, 'down')} className="p-1 rounded hover:bg-white/[0.08] transition-colors">
                        <ChevronDownIcon size={11} color="var(--sub)" />
                      </button>
                    </div>
                    <span className="flex-1 text-[13px] font-semibold text-[var(--text)] truncate">{link.title || 'Untitled'}</span>
                    <span className="text-[11px] text-[var(--sub)] font-mono">{link.clicks} clicks</span>
                    <button
                      onClick={() => handleDeleteLink(link.id)}
                      className="p-1.5 rounded-lg hover:bg-[rgba(255,77,109,0.12)] transition-colors"
                    >
                      <TrashIcon size={13} color="#ff4d6d" />
                    </button>
                  </div>
                  <input
                    className="gaze-input text-[13px]"
                    value={link.title}
                    placeholder="Title"
                    onChange={e => handleUpdateLink(link.id, 'title', e.target.value)}
                    onBlur={() => handleBlurLink(link)}
                  />
                  <input
                    className="gaze-input text-[13px]"
                    value={link.url}
                    placeholder="URL"
                    onChange={e => handleUpdateLink(link.id, 'url', e.target.value)}
                    onBlur={() => handleBlurLink(link)}
                  />
                </div>
              ))}
            </div>
          )}

          {/* ── DESIGN TAB ─── */}
          {tab === 'design' && (
            <div className="space-y-6 animate-fade-in">
              {/* Themes */}
              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-3 block">Theme Preset</label>
                <div className="space-y-2">
                  {Object.entries(THEMES).map(([name, t]) => (
                    <button
                      key={name}
                      onClick={() => saveProfile({ theme: name as ThemeName, accent_color: t.accent, font: t.font as FontName, btn_style: t.btnStyle as ButtonStyle })}
                      className="flex items-center gap-3 w-full px-3 py-2.5 rounded-[10px] border transition-all text-left"
                      style={{
                        background: profile.theme === name ? 'rgba(0,245,196,0.07)' : 'rgba(255,255,255,0.03)',
                        borderColor: profile.theme === name ? 'rgba(0,245,196,0.3)' : 'var(--glass-border)',
                      }}
                    >
                      <div className="flex gap-1">
                        {t.preview.map((c, i) => (
                          <div key={i} style={{ width: 16, height: 16, borderRadius: 4, background: c, border: '1px solid rgba(255,255,255,0.1)' }} />
                        ))}
                      </div>
                      <span
                        className="flex-1 text-[13px] font-medium"
                        style={{ color: profile.theme === name ? 'var(--accent)' : 'var(--text)' }}
                      >
                        {name}
                      </span>
                      {profile.theme === name && <CheckIcon size={14} color="var(--accent)" />}
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-[var(--glass-border)]" />

              {/* Accent color */}
              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-2 block">Accent Color</label>
                <div className="flex items-center gap-2.5">
                  <input
                    type="color"
                    value={profile.accent_color}
                    onChange={e => setProfile(p => ({ ...p, accent_color: e.target.value }))}
                    onBlur={() => saveProfile({ accent_color: profile.accent_color })}
                    className="w-10 h-10 rounded-lg border border-[var(--glass-border)] cursor-pointer bg-none p-0.5"
                  />
                  <input
                    className="gaze-input flex-1 font-mono text-[13px]"
                    value={profile.accent_color}
                    onChange={e => setProfile(p => ({ ...p, accent_color: e.target.value }))}
                    onBlur={() => saveProfile({ accent_color: profile.accent_color })}
                  />
                </div>
              </div>

              {/* Font */}
              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-2 block">Font</label>
                <div className="grid grid-cols-2 gap-2">
                  {FONTS.map(f => (
                    <button
                      key={f}
                      onClick={() => saveProfile({ font: f })}
                      className="py-2.5 px-3 rounded-lg border text-[13px] transition-all"
                      style={{
                        fontFamily: `'${f}', sans-serif`,
                        borderColor: profile.font === f ? profile.accent_color : 'var(--glass-border)',
                        background: profile.font === f ? `${profile.accent_color}12` : 'rgba(255,255,255,0.02)',
                        color: profile.font === f ? profile.accent_color : 'var(--text)',
                      }}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Button style */}
              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-2 block">Button Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(BUTTON_STYLES) as ButtonStyle[]).map(bs => (
                    <button
                      key={bs}
                      onClick={() => saveProfile({ btn_style: bs })}
                      className="py-2.5 px-3 rounded-lg border text-[13px] font-medium capitalize transition-all"
                      style={{
                        borderColor: profile.btn_style === bs ? profile.accent_color : 'var(--glass-border)',
                        background: profile.btn_style === bs ? `${profile.accent_color}12` : 'rgba(255,255,255,0.02)',
                        color: profile.btn_style === bs ? profile.accent_color : 'var(--text)',
                      }}
                    >
                      {bs}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── RIGHT: LIVE PREVIEW ─────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden bg-black/20">
        {/* Fake browser bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[var(--glass-border)] bg-[var(--glass)] backdrop-blur-xl">
          <div className="flex gap-1.5">
            {['#ff5f57', '#febc2e', '#28c840'].map(c => (
              <div key={c} style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />
            ))}
          </div>
          <div className="flex-1 bg-white/[0.05] rounded-md px-3 py-1.5 text-[12px] text-[var(--sub)] font-mono">
            gazebio.vercel.app/<span style={{ color: 'var(--accent)' }}>{profile.username}</span>
          </div>
          <span className="text-[11px] text-[var(--sub)]">Live Preview</span>
        </div>

        <div className="flex-1 overflow-y-auto flex justify-center p-5">
          <div className="w-full max-w-[390px]">
            <PublicProfile profile={profile} links={links} isPreview />
          </div>
        </div>
      </div>
    </div>
  )
}
