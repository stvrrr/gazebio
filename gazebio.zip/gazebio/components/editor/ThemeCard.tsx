'use client'

import type { ThemeConfig } from '@/lib/themes'
import { CheckIcon } from '@/components/ui/Icon'

interface Props {
  theme: ThemeConfig
  selected: boolean
  onClick: () => void
}

export function ThemeCard({ theme, selected, onClick }: Props) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 w-full px-3 py-2.5 rounded-[10px] border transition-all text-left"
      style={{
        background: selected ? 'rgba(0,245,196,0.07)' : 'rgba(255,255,255,0.03)',
        borderColor: selected ? 'rgba(0,245,196,0.3)' : 'var(--glass-border)',
      }}
    >
      {/* Color swatches */}
      <div className="flex gap-1 flex-shrink-0">
        {theme.preview.map((color, i) => (
          <div
            key={i}
            style={{
              width: 16,
              height: 16,
              borderRadius: 4,
              background: color,
              border: '1px solid rgba(255,255,255,0.1)',
            }}
          />
        ))}
      </div>

      {/* Name */}
      <span
        className="flex-1 text-[13px] font-medium"
        style={{ color: selected ? 'var(--accent)' : 'var(--text)' }}
      >
        {theme.name}
      </span>

      {/* Check */}
      {selected && <CheckIcon size={14} color="var(--accent)" />}
    </button>
  )
}
