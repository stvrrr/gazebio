'use client'

import type { LinkRow } from '@/lib/types'
import { ChevronUpIcon, ChevronDownIcon, TrashIcon } from '@/components/ui/Icon'

interface Props {
  link: LinkRow
  isFirst: boolean
  isLast: boolean
  onMoveUp: () => void
  onMoveDown: () => void
  onDelete: () => void
  onChangeTitle: (val: string) => void
  onChangeUrl: (val: string) => void
  onBlur: () => void
}

export function LinkCard({
  link,
  isFirst,
  isLast,
  onMoveUp,
  onMoveDown,
  onDelete,
  onChangeTitle,
  onChangeUrl,
  onBlur,
}: Props) {
  return (
    <div className="glass-card p-3.5 space-y-2.5">
      {/* Header row */}
      <div className="flex items-center gap-2">
        {/* Reorder controls */}
        <div className="flex flex-col gap-0.5">
          <button
            onClick={onMoveUp}
            disabled={isFirst}
            className="p-1 rounded hover:bg-white/[0.08] transition-colors disabled:opacity-30"
          >
            <ChevronUpIcon size={11} color="var(--sub)" />
          </button>
          <button
            onClick={onMoveDown}
            disabled={isLast}
            className="p-1 rounded hover:bg-white/[0.08] transition-colors disabled:opacity-30"
          >
            <ChevronDownIcon size={11} color="var(--sub)" />
          </button>
        </div>

        {/* Title preview */}
        <span className="flex-1 text-[13px] font-semibold text-[var(--text)] truncate">
          {link.title || 'Untitled'}
        </span>

        {/* Click count */}
        <span className="text-[11px] text-[var(--sub)] font-mono flex-shrink-0">
          {link.clicks.toLocaleString()} clicks
        </span>

        {/* Delete */}
        <button
          onClick={onDelete}
          className="p-1.5 rounded-lg hover:bg-[rgba(255,77,109,0.12)] transition-colors"
          title="Delete link"
        >
          <TrashIcon size={13} color="#ff4d6d" />
        </button>
      </div>

      {/* Editable fields */}
      <input
        className="gaze-input text-[13px]"
        value={link.title}
        placeholder="Link title"
        onChange={e => onChangeTitle(e.target.value)}
        onBlur={onBlur}
      />
      <input
        className="gaze-input text-[13px]"
        value={link.url}
        placeholder="https://..."
        onChange={e => onChangeUrl(e.target.value)}
        onBlur={onBlur}
      />
    </div>
  )
}
