'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { createClient } from '@/lib/supabase/client'
import { GazeWordmark } from '@/components/ui/GazeWordmark'
import { slugify } from '@/lib/utils'

interface Props {
  mode: 'login' | 'signup'
}

export default function AuthForm({ mode }: Props) {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    const supabase = createClient()

    try {
      if (mode === 'signup') {
        if (username.length < 2) {
          toast.error('Username must be at least 2 characters')
          setLoading(false)
          return
        }

        // Check username availability
        const { data: existing } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', username)
          .single()

        if (existing) {
          toast.error('That username is already taken')
          setLoading(false)
          return
        }

        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/auth/callback`,
            data: { username },
          },
        })

        if (error) throw error

        toast.success('Account created! Check your email to confirm.')
        router.push('/dashboard')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        router.push('/dashboard')
        router.refresh()
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      toast.error(message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] px-5 py-12 relative overflow-hidden">
      {/* Ambient orbs */}
      <div className="absolute top-[10%] left-[10%] w-[400px] h-[400px] rounded-full pointer-events-none animate-orb1"
        style={{ background: 'radial-gradient(circle, rgba(0,245,196,0.12) 0%, transparent 70%)' }} />
      <div className="absolute bottom-[10%] right-[5%] w-[350px] h-[350px] rounded-full pointer-events-none animate-orb2"
        style={{ background: 'radial-gradient(circle, rgba(124,58,237,0.12) 0%, transparent 70%)' }} />

      <div className="w-full max-w-[420px] animate-fade-up">
        {/* Wordmark */}
        <div className="text-center mb-9">
          <div className="flex justify-center mb-4">
            <GazeWordmark size="lg" href="/" />
          </div>
          <p className="text-[var(--sub)] text-[15px]">
            {mode === 'login'
              ? 'Welcome back. Sign in to your page.'
              : 'Your link. Your identity. Elevated.'}
          </p>
        </div>

        <div className="glass-card p-8">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === 'signup' && (
              <div>
                <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">
                  Username
                </label>
                <input
                  className="gaze-input"
                  type="text"
                  placeholder="your_username"
                  value={username}
                  onChange={e => setUsername(slugify(e.target.value))}
                  required
                  minLength={2}
                  maxLength={30}
                  autoComplete="username"
                />
                <p className="text-[11px] text-[var(--sub)] mt-1.5">
                  Your public URL:{' '}
                  <span className="text-[var(--accent)] font-mono">
                    gazebio.vercel.app/{username || 'username'}
                  </span>
                </p>
              </div>
            )}

            <div>
              <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">
                Email
              </label>
              <input
                className="gaze-input"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-1.5 block">
                Password
              </label>
              <input
                className="gaze-input"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 px-5 py-3.5 mt-2 rounded-[10px] bg-gradient-to-r from-accent to-[#00c4f5] text-[#020c0a] font-semibold text-[15px] shadow-[0_0_24px_rgba(0,245,196,0.25)] hover:shadow-[0_0_36px_rgba(0,245,196,0.45)] hover:-translate-y-0.5 active:translate-y-0 transition-all disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-[rgba(0,0,0,0.3)] border-t-[#020c0a] rounded-full animate-spin" />
              ) : mode === 'login' ? 'Sign In' : 'Create My Page'}
            </button>
          </form>

          <p className="text-center text-[13px] text-[var(--sub)] mt-5">
            {mode === 'login' ? "Don't have an account? " : 'Already have one? '}
            <Link
              href={mode === 'login' ? '/signup' : '/login'}
              className="text-[var(--accent)] hover:underline font-medium"
            >
              {mode === 'login' ? 'Sign up free' : 'Sign in'}
            </Link>
          </p>
        </div>

        <div className="flex justify-center gap-4 mt-6 flex-wrap">
          {['🌐 Public profiles', '⚡ Instant setup', '🎨 6 themes'].map(f => (
            <span
              key={f}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[rgba(255,255,255,0.04)] border border-[var(--glass-border)] text-[12px] text-[var(--sub)]"
            >
              {f}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
