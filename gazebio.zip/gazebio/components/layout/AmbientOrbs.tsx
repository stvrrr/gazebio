'use client'

interface Orb {
  top?: string
  bottom?: string
  left?: string
  right?: string
  color: string
  size: number
  animation: 'animate-orb1' | 'animate-orb2'
  opacity?: number
}

interface Props {
  orbs?: Orb[]
}

const DEFAULT_ORBS: Orb[] = [
  {
    top: '10%',
    left: '10%',
    color: '#00f5c4',
    size: 400,
    animation: 'animate-orb1',
    opacity: 0.12,
  },
  {
    bottom: '10%',
    right: '5%',
    color: '#7c3aed',
    size: 350,
    animation: 'animate-orb2',
    opacity: 0.1,
  },
]

export function AmbientOrbs({ orbs = DEFAULT_ORBS }: Props) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {orbs.map((orb, i) => (
        <div
          key={i}
          className={`absolute rounded-full ${orb.animation}`}
          style={{
            top: orb.top,
            bottom: orb.bottom,
            left: orb.left,
            right: orb.right,
            width: orb.size,
            height: orb.size,
            background: `radial-gradient(circle, ${orb.color} 0%, transparent 70%)`,
            opacity: orb.opacity ?? 0.12,
          }}
        />
      ))}
    </div>
  )
}
