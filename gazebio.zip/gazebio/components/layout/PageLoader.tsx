import { GazeWordmark } from '@/components/ui/GazeWordmark'

export function PageLoader() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 bg-[#070710]">
      <GazeWordmark size="md" />
      <div
        className="w-6 h-6 rounded-full border-2 border-white/10 border-t-[var(--accent)] animate-spin"
      />
    </div>
  )
}
