'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import type { User } from '@supabase/supabase-js'
import type { ProfileRow } from '@/lib/types'
import { GazeWordmark } from '@/components/ui/GazeWordmark'
import { Avatar } from '@/components/ui/Avatar'
import {
  GridIcon, EditIcon, EyeIcon, LogOutIcon, ChevronDownIcon,
} from '@/components/ui/Icon'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

interface Props {
  children: React.ReactNode
  profile: ProfileRow
  user: User
  fullWidth?: boolean
}

const NAV_LINKS = [
  { href: '/dashboard', label: 'Dashboard', Icon: GridIcon },
  { href: '/editor', label: 'Editor', Icon: EditIcon },
  { href: '/preview', label: 'Preview', Icon: EyeIcon },
]

export default function AppShell({ children, profile, user, fullWidth = false }: Props) {
  const pathname = usePathname()
  const router = useRouter()
  const [dropOpen, setDropOpen] = useState(false)
  const dropRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setDropOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg)]">
      {/* Top Nav */}
      <nav className="h-[60px] flex items-center px-6 gap-2 border-b border-[var(--glass-border)] bg-[rgba(7,7,16,0.85)] backdrop-blur-xl sticky top-0 z-50">
        <GazeWordmark size="sm" href="/dashboard" />

        <div className="flex gap-1 ml-5 flex-1">
          {NAV_LINKS.map(({ href, label, Icon }) => {
            const active = pathname === href
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-[10px] text-[14px] font-medium transition-all duration-150 ${
                  active
                    ? 'bg-[rgba(0,245,196,0.1)] text-[var(--accent)]'
                    : 'text-[var(--sub)] hover:bg-[var(--glass)] hover:text-[var(--text)]'
                }`}
              >
                <Icon size={14} color={active ? 'var(--accent)' : 'var(--sub)'} />
                {label}
              </Link>
            )
          })}


        </div>

        {/* User dropdown */}
        <div className="relative" ref={dropRef}>
          <button
            onClick={() => setDropOpen(!dropOpen)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-[10px] bg-[var(--glass)] border border-[var(--glass-border)] cursor-pointer transition-all hover:bg-[var(--glass-hover)]"
          >
            <Avatar
              name={profile.display_name || profile.username}
              accentColor={profile.accent_color}
              avatarUrl={profile.avatar_url}
              size={26}
            />
            <span className="text-[13px] font-medium text-[var(--text)]">
              {profile.username}
            </span>
            <ChevronDownIcon size={12} color="var(--sub)" />
          </button>

          {dropOpen && (
            <div className="absolute right-0 top-[calc(100%+8px)] w-52 glass-card p-2 z-[200] shadow-[0_16px_48px_rgba(0,0,0,0.5)] animate-fade-up">
              <div className="px-3 py-2 mb-1">
                <div className="text-[13px] font-semibold text-[var(--text)]">{profile.display_name || profile.username}</div>
                <div className="text-[11px] text-[var(--sub)]">{user.email}</div>
              </div>
              <hr className="border-[var(--glass-border)] my-1" />
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 w-full px-3 py-2 rounded-[8px] text-[13px] text-[#ff4d6d] hover:bg-[rgba(255,77,109,0.08)] transition-colors"
              >
                <LogOutIcon size={14} color="#ff4d6d" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Main content */}
      <main className={`flex-1 ${fullWidth ? '' : 'max-w-[1140px] mx-auto w-full px-6'}`}>
        {children}
      </main>
    </div>
  )
}
