'use client'

import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import type { ProfileRow, LinkRow } from '@/lib/types'
import { StatCard } from '@/components/ui/StatCard'
import { Avatar } from '@/components/ui/Avatar'
import {
  EyeIcon, ZapIcon, LinkIcon, ChartIcon, EditIcon, CopyIcon,
} from '@/components/ui/Icon'
import { getTheme } from '@/lib/themes'
import { formatNumber } from '@/lib/utils'

interface Stats {
  total_views: number
  total_clicks: number
  link_count: number
}

interface Props {
  profile: ProfileRow
  links: LinkRow[]
  stats: Stats | null
}

function ClickBar({
  title, clicks, maxClicks, accent, isTop,
}: {
  title: string; clicks: number; maxClicks: number; accent: string; isTop: boolean
}) {
  const pct = Math.max(5, (clicks / maxClicks) * 100)
  return (
    <div className="py-3 border-b border-[var(--glass-border)] last:border-0">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          {isTop && (
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[rgba(0,245,196,0.12)] text-[var(--accent)] border border-[rgba(0,245,196,0.25)] uppercase tracking-wide">
              Top
            </span>
          )}
          <span className="text-[13px] text-[var(--text)] font-medium">{title}</span>
        </div>
        <span className="text-[13px] text-[var(--sub)] font-mono">{formatNumber(clicks)}</span>
      </div>
      <div className="h-1 rounded-full bg-white/[0.06] overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{
            width: `${pct}%`,
            background: isTop ? `linear-gradient(90deg, ${accent}, #00c4f5)` : 'rgba(255,255,255,0.15)',
            boxShadow: isTop ? `0 0 8px ${accent}60` : 'none',
          }}
        />
      </div>
    </div>
  )
}

export default function DashboardView({ profile, links, stats }: Props) {
  const router = useRouter()
  const theme = getTheme(profile.theme)

  const totalViews = stats?.total_views ?? 0
  const totalClicks = stats?.total_clicks ?? 0
  const linkCount = stats?.link_count ?? links.length
  const engagement = totalViews > 0 ? Math.round((totalClicks / totalViews) * 100) : 0

  const maxClicks = links.length > 0 ? Math.max(...links.map(l => l.clicks), 1) : 1

  const copyLink = () => {
    navigator.clipboard
      .writeText(`https://gazebio.vercel.app/${profile.username}`)
      .then(() => toast.success('Link copied!'))
      .catch(() => toast.error('Failed to copy'))
  }

  return (
    <div className="py-7 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-syne text-2xl font-black tracking-tight text-[var(--text)]">
            Welcome back{profile.display_name ? `, ${profile.display_name.split(' ')[0]}` : ''}
          </h1>
          <p className="text-[14px] text-[var(--sub)] mt-0.5">Here's how your page is performing</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => router.push('/editor')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-[10px] bg-[var(--glass)] border border-[var(--glass-border)] text-[var(--text)] text-[13px] font-medium hover:bg-[var(--glass-hover)] hover:-translate-y-px transition-all"
          >
            <EditIcon size={14} /> Edit Page
          </button>
          <a
            href={`https://gazebio.vercel.app/${profile.username}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-[10px] bg-[var(--glass)] border border-[var(--glass-border)] text-[var(--text)] text-[13px] font-medium hover:bg-[var(--glass-hover)] hover:-translate-y-px transition-all"
          >
            <EyeIcon size={14} /> View Live
          </a>
          <button
            onClick={copyLink}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-[10px] bg-[var(--glass)] border border-[var(--glass-border)] text-[var(--text)] text-[13px] font-medium hover:bg-[var(--glass-hover)] hover:-translate-y-px transition-all"
          >
            <CopyIcon size={14} /> Copy Link
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <StatCard icon={<EyeIcon size={17} color="#00f5c4" />} rawValue={totalViews} label="Profile Views" color="#00f5c4" delay={0} />
        <StatCard icon={<ZapIcon size={17} color="#7c3aed" />} rawValue={totalClicks} label="Total Clicks" color="#7c3aed" delay={80} />
        <StatCard icon={<LinkIcon size={17} color="#38bdf8" />} rawValue={linkCount} label="Active Links" color="#38bdf8" delay={160} />
        <StatCard icon={<ChartIcon size={17} color="#f472b6" />} rawValue={engagement} label="Engagement" color="#f472b6" delay={240} suffix="%" />
      </div>

      {/* Bottom grid */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-4">
        {/* Link analytics */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-syne text-[16px] font-bold text-[var(--text)]">Link Performance</h2>
            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[rgba(0,245,196,0.12)] text-[var(--accent)] border border-[rgba(0,245,196,0.25)]">
              All time
            </span>
          </div>
          {links.length === 0 ? (
            <div className="text-center py-10 text-[var(--sub)] text-[14px]">
              No links yet.{' '}
              <button onClick={() => router.push('/editor')} className="text-[var(--accent)] hover:underline">
                Add your first link →
              </button>
            </div>
          ) : (
            links.map((link, i) => (
              <ClickBar
                key={link.id}
                title={link.title}
                clicks={link.clicks}
                maxClicks={maxClicks}
                accent={profile.accent_color}
                isTop={i === 0}
              />
            ))
          )}
        </div>

        {/* Right column */}
        <div className="flex flex-col gap-4">
          {/* Profile card */}
          <button
            onClick={() => router.push('/editor')}
            className="glass-card glass-card-hover p-5 text-left w-full"
          >
            <div className="flex items-center gap-3.5">
              <Avatar
                name={profile.display_name || profile.username}
                accentColor={profile.accent_color}
                avatarUrl={profile.avatar_url}
                size={52}
              />
              <div className="flex-1 min-w-0">
                <div className="font-syne font-bold text-[15px] text-[var(--text)] truncate">
                  {profile.display_name || profile.username}
                </div>
                <div className="text-[12px] text-[var(--sub)] mt-0.5 truncate">
                  gazebio.vercel.app/{profile.username}
                </div>
                <span className="inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[rgba(124,58,237,0.15)] text-[#a78bfa] border border-[rgba(124,58,237,0.3)]">
                  {profile.theme}
                </span>
              </div>
              <EditIcon size={14} color="var(--sub)" />
            </div>
          </button>

          {/* Theme selector preview */}
          <div className="glass-card p-5">
            <div className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-3.5">Active Theme</div>
            <div className="flex gap-2 flex-wrap">
              {Object.entries({ 'Dark Modern': ['#070710', '#00f5c4'], 'Neon Gamer': ['#050510', '#00f5c4'], 'Cyberpunk Glow': ['#0a0005', '#ff007f'], 'Soft Aesthetic': ['#1a0f1f', '#c084fc'], 'Gradient Glass': ['#0a1628', '#38bdf8'], 'Minimal Light': ['#f0f4ff', '#6c63ff'] }).map(([name, [bg, accent]]) => (
                <div
                  key={name}
                  title={name}
                  style={{
                    width: 28, height: 28, borderRadius: 8,
                    background: `linear-gradient(135deg, ${bg}, ${accent})`,
                    border: profile.theme === name ? `2px solid ${profile.accent_color}` : '2px solid transparent',
                    boxShadow: profile.theme === name ? `0 0 10px ${profile.accent_color}60` : 'none',
                    transition: 'all 0.2s',
                    transform: profile.theme === name ? 'scale(1.2)' : 'scale(1)',
                  }}
                />
              ))}
            </div>
            <div className="text-[13px] text-[var(--text)] font-medium mt-3">{profile.theme}</div>
            <button
              onClick={() => router.push('/editor')}
              className="text-[12px] text-[var(--accent)] mt-1.5 hover:underline block"
            >
              Change theme →
            </button>
          </div>

          {/* Your link */}
          <div className="glass-card p-5">
            <div className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em] mb-3">Your Link</div>
            <div className="flex items-center gap-2 bg-white/[0.04] rounded-[8px] px-3 py-2 border border-[var(--glass-border)]">
              <EyeIcon size={13} color="var(--accent)" />
              <span className="flex-1 text-[13px] font-mono text-[var(--text)] truncate">
                gazebio.vercel.app/<span className="text-[var(--accent)]">{profile.username}</span>
              </span>
              <button
                onClick={copyLink}
                className="p-1 rounded-[6px] hover:bg-white/[0.08] transition-colors"
                title="Copy link"
              >
                <CopyIcon size={13} color="var(--sub)" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
