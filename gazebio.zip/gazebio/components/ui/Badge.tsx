import { cn } from '@/lib/utils'
import type { ReactNode } from 'react'

type BadgeVariant = 'accent' | 'purple' | 'danger' | 'neutral'

interface Props {
  variant?: BadgeVariant
  children: ReactNode
  className?: string
}

const variantStyles: Record<BadgeVariant, string> = {
  accent:
    'bg-[rgba(0,245,196,0.12)] text-[var(--accent)] border-[rgba(0,245,196,0.25)]',
  purple:
    'bg-[rgba(124,58,237,0.15)] text-[#a78bfa] border-[rgba(124,58,237,0.3)]',
  danger:
    'bg-[rgba(255,77,109,0.12)] text-[#ff4d6d] border-[rgba(255,77,109,0.3)]',
  neutral:
    'bg-[rgba(255,255,255,0.06)] text-[var(--sub)] border-[var(--glass-border)]',
}

export function Badge({ variant = 'neutral', children, className }: Props) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold border tracking-wide uppercase',
        variantStyles[variant],
        className
      )}
    >
      {children}
    </span>
  )
}
