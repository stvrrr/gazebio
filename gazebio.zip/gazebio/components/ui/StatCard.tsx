'use client'

import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'

interface Props {
  icon: ReactNode
  rawValue: number
  label: string
  color?: string
  delay?: number
  suffix?: string
}

export function StatCard({
  icon,
  rawValue,
  label,
  color = '#00f5c4',
  delay = 0,
  suffix = '',
}: Props) {
  const [displayed, setDisplayed] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      let start = 0
      const duration = 1200
      const step = (rawValue / duration) * 16
      const interval = setInterval(() => {
        start += step
        if (start >= rawValue) {
          setDisplayed(rawValue)
          clearInterval(interval)
        } else {
          setDisplayed(Math.floor(start))
        }
      }, 16)
      return () => clearInterval(interval)
    }, delay)
    return () => clearTimeout(timer)
  }, [rawValue, delay])

  const formatted =
    displayed >= 1_000_000
      ? (displayed / 1_000_000).toFixed(1) + 'M'
      : displayed >= 1_000
      ? (displayed / 1_000).toFixed(1) + 'k'
      : displayed.toString()

  return (
    <div
      className="glass-card glass-card-hover p-6 relative overflow-hidden"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Ambient glow */}
      <div
        className="absolute -top-5 -right-5 w-20 h-20 rounded-full pointer-events-none"
        style={{ background: `radial-gradient(circle, ${color}18 0%, transparent 70%)` }}
      />

      <div
        className="w-[38px] h-[38px] rounded-[10px] flex items-center justify-center mb-4"
        style={{
          background: `${color}18`,
          border: `1px solid ${color}30`,
          color,
        }}
      >
        {icon}
      </div>

      <div
        className="font-syne text-[26px] font-black tracking-tight text-[#e8eaf6] leading-none"
      >
        {formatted}{suffix}
      </div>
      <div className="text-xs text-[var(--sub)] mt-1 font-medium">{label}</div>
    </div>
  )
}
