import { cn } from '@/lib/utils'

interface Props {
  size?: number
  color?: string
  className?: string
}

export function Spinner({ size = 16, color = 'currentColor', className }: Props) {
  return (
    <span
      className={cn('inline-block rounded-full border-2 animate-spin', className)}
      style={{
        width: size,
        height: size,
        borderColor: `${color}30`,
        borderTopColor: color,
      }}
    />
  )
}
