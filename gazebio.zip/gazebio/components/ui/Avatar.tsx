'use client'

import Image from 'next/image'
import { getInitials } from '@/lib/utils'

interface Props {
  name: string
  accentColor?: string
  avatarUrl?: string | null
  size?: number
  showCamera?: boolean
  onClick?: () => void
  className?: string
}

export function Avatar({
  name,
  accentColor = '#00f5c4',
  avatarUrl,
  size = 56,
  showCamera = false,
  onClick,
  className = '',
}: Props) {
  const initials = getInitials(name || 'U')

  return (
    <div
      className={`relative inline-block ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
      style={{ width: size, height: size }}
    >
      <div
        style={{
          width: size,
          height: size,
          borderRadius: '50%',
          background: avatarUrl
            ? 'transparent'
            : `radial-gradient(circle, ${accentColor}40, ${accentColor}10)`,
          border: `2px solid ${accentColor}50`,
          boxShadow: `0 0 20px ${accentColor}30`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: size * 0.3,
          fontFamily: 'var(--font-syne)',
          fontWeight: 700,
          color: accentColor,
          overflow: 'hidden',
          transition: 'transform 0.2s, box-shadow 0.2s',
          userSelect: 'none',
        }}
        onMouseEnter={e => {
          if (onClick) {
            const el = e.currentTarget as HTMLDivElement
            el.style.transform = 'scale(1.05)'
            el.style.boxShadow = `0 0 30px ${accentColor}50`
          }
        }}
        onMouseLeave={e => {
          if (onClick) {
            const el = e.currentTarget as HTMLDivElement
            el.style.transform = 'scale(1)'
            el.style.boxShadow = `0 0 20px ${accentColor}30`
          }
        }}
      >
        {avatarUrl ? (
          <Image src={avatarUrl} alt={name} fill className="object-cover" />
        ) : (
          initials
        )}
      </div>

      {showCamera && (
        <div
          className="absolute bottom-0 right-0 flex items-center justify-center rounded-full bg-[var(--surface2)] border-2 border-[var(--bg)]"
          style={{ width: 24, height: 24 }}
        >
          <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="var(--sub)" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
          </svg>
        </div>
      )}
    </div>
  )
}
