'use client'

import Link from 'next/link'

interface Props {
  size?: 'sm' | 'md' | 'lg'
  href?: string
}

const sizes = {
  sm: { dot: 22, font: 17 },
  md: { dot: 28, font: 22 },
  lg: { dot: 36, font: 32 },
}

export function GazeWordmark({ size = 'md', href = '/' }: Props) {
  const s = sizes[size]

  const inner = (
    <span className="flex items-center gap-2 select-none">
      <span
        style={{ width: s.dot, height: s.dot }}
        className="rounded-full bg-gradient-to-br from-accent to-[#00c4f5] flex items-center justify-center flex-shrink-0 shadow-[0_0_16px_rgba(0,245,196,0.4)]"
      >
        <span
          style={{ width: '42%', height: '42%' }}
          className="rounded-full bg-[#070710]"
        />
      </span>
      <span
        style={{ fontSize: s.font, letterSpacing: '-0.03em' }}
        className="font-syne font-extrabold text-[#e8eaf6]"
      >
        gaze<span className="text-accent">.</span>
      </span>
    </span>
  )

  return href ? (
    <Link href={href} className="hover:opacity-90 transition-opacity">
      {inner}
    </Link>
  ) : (
    inner
  )
}
