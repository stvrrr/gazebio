import { cn } from '@/lib/utils'
import type { ButtonHTMLAttributes, ReactNode } from 'react'

type Variant = 'default' | 'primary' | 'danger' | 'ghost'
type Size = 'sm' | 'md' | 'lg'

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  iconOnly?: boolean
  children: ReactNode
}

const variantStyles: Record<Variant, string> = {
  default:
    'bg-[var(--glass)] border-[var(--glass-border)] text-[var(--text)] hover:bg-[var(--glass-hover)] hover:border-white/[0.18]',
  primary:
    'bg-gradient-to-r from-accent to-[#00c4f5] border-transparent text-[#020c0a] font-semibold shadow-[0_0_24px_rgba(0,245,196,0.25)] hover:shadow-[0_0_36px_rgba(0,245,196,0.45)]',
  danger:
    'bg-[rgba(255,77,109,0.12)] border-[rgba(255,77,109,0.3)] text-[#ff4d6d] hover:bg-[rgba(255,77,109,0.2)] hover:border-[rgba(255,77,109,0.5)]',
  ghost:
    'bg-transparent border-transparent text-[var(--sub)] hover:bg-[var(--glass)] hover:text-[var(--text)]',
}

const sizeStyles: Record<Size, string> = {
  sm: 'px-3.5 py-1.5 text-[13px] rounded-lg gap-1.5',
  md: 'px-5 py-2.5 text-[14px] rounded-[10px] gap-2',
  lg: 'px-6 py-3 text-[15px] rounded-xl gap-2',
}

export function Button({
  variant = 'default',
  size = 'md',
  loading = false,
  iconOnly = false,
  className,
  children,
  disabled,
  ...props
}: Props) {
  return (
    <button
      disabled={disabled || loading}
      className={cn(
        'inline-flex items-center justify-center border font-medium cursor-pointer',
        'backdrop-blur-md transition-all duration-200 outline-none',
        'hover:-translate-y-px active:translate-y-0',
        'disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none',
        'whitespace-nowrap select-none',
        variantStyles[variant],
        iconOnly ? 'p-2 rounded-lg' : sizeStyles[size],
        className
      )}
      {...props}
    >
      {loading ? (
        <span
          className="inline-block w-4 h-4 border-2 border-current/30 border-t-current rounded-full animate-spin"
        />
      ) : (
        children
      )}
    </button>
  )
}
