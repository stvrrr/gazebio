import { cn } from '@/lib/utils'

export function Divider({ className }: { className?: string }) {
  return (
    <hr className={cn('border-none border-t border-[var(--glass-border)]', className)} />
  )
}
