import { cn } from '@/lib/utils'
import type { InputHTMLAttributes, TextareaHTMLAttributes } from 'react'

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  hint?: string
  prefix?: string
  error?: string
}

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  hint?: string
  error?: string
}

export function Input({ label, hint, prefix, error, className, ...props }: InputProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em]">
          {label}
        </label>
      )}
      <div className="relative">
        {prefix && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--sub)] text-sm pointer-events-none select-none">
            {prefix}
          </span>
        )}
        <input
          className={cn(
            'gaze-input',
            error && 'border-[#ff4d6d] focus:border-[#ff4d6d] focus:shadow-[0_0_0_3px_rgba(255,77,109,0.1)]',
            prefix && 'pl-[calc(8px+var(--prefix-width,48px))]',
            className
          )}
          style={prefix ? { paddingLeft: `${prefix.length * 8 + 16}px` } : undefined}
          {...props}
        />
      </div>
      {hint && !error && (
        <p className="text-[11px] text-[var(--sub)]">{hint}</p>
      )}
      {error && (
        <p className="text-[11px] text-[#ff4d6d]">{error}</p>
      )}
    </div>
  )
}

export function Textarea({ label, hint, error, className, ...props }: TextareaProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label className="text-[11px] font-medium text-[var(--sub)] uppercase tracking-[0.08em]">
          {label}
        </label>
      )}
      <textarea
        className={cn(
          'gaze-input resize-none leading-relaxed',
          error && 'border-[#ff4d6d]',
          className
        )}
        {...props}
      />
      {hint && !error && <p className="text-[11px] text-[var(--sub)]">{hint}</p>}
      {error && <p className="text-[11px] text-[#ff4d6d]">{error}</p>}
    </div>
  )
}
