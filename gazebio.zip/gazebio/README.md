# Gaze — BioLinks

> Your link. Your identity. Elevated.

A premium, glassmorphism bio link page builder for creators and gamers.
Live at **[gazebio.vercel.app](https://gazebio.vercel.app)**

---

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + custom CSS variables
- **Auth & DB**: Supabase (Postgres + Auth + Storage)
- **Animations**: Framer Motion + CSS keyframes
- **Toasts**: react-hot-toast
- **State**: React useState + Server Actions
- **Deployment**: Vercel

---

## Project Structure

```
gazebio/
├── app/
│   ├── layout.tsx              # Root layout, fonts, metadata
│   ├── page.tsx                # Redirects to /dashboard or /login
│   ├── login/page.tsx
│   ├── signup/page.tsx
│   ├── dashboard/page.tsx
│   ├── editor/page.tsx
│   ├── auth/callback/route.ts  # Supabase OAuth callback
│   ├── [username]/page.tsx     # Public profile page
│   └── not-found.tsx
│
├── components/
│   ├── auth/
│   │   └── AuthForm.tsx        # Login + signup form
│   ├── layout/
│   │   └── AppShell.tsx        # Nav + page shell
│   ├── dashboard/
│   │   └── DashboardView.tsx   # Stats, analytics, quick actions
│   ├── editor/
│   │   └── EditorView.tsx      # Split panel editor + live preview
│   ├── profile/
│   │   └── PublicProfile.tsx   # Themed public profile page
│   └── ui/
│       ├── GazeWordmark.tsx
│       ├── Avatar.tsx
│       ├── Button.tsx
│       ├── Input.tsx
│       ├── StatCard.tsx
│       └── Icon.tsx
│
├── lib/
│   ├── types.ts                # TypeScript interfaces
│   ├── themes.ts               # 6 theme presets + utilities
│   ├── utils.ts                # Helpers (cn, formatNumber, etc.)
│   ├── actions/
│   │   ├── auth.ts             # Server actions for auth
│   │   └── profile.ts          # Server actions for profiles + links
│   └── supabase/
│       ├── client.ts           # Browser Supabase client
│       ├── server.ts           # Server Supabase client
│       └── middleware.ts       # Session refresh middleware
│
├── styles/
│   └── globals.css             # Tailwind + CSS variables + animations
│
├── supabase/
│   └── schema.sql              # Full DB schema with RLS + functions
│
├── middleware.ts               # Next.js route protection
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
└── vercel.json
```

---

## Setup

### 1. Clone and install

```bash
git clone https://github.com/yourusername/gazebio.git
cd gazebio
npm install
```

### 2. Create a Supabase project

1. Go to [app.supabase.com](https://app.supabase.com) and create a new project
2. Copy your **Project URL** and **Anon Key** from Settings → API

### 3. Run the database schema

1. In your Supabase dashboard, go to **SQL Editor → New query**
2. Paste the full contents of `supabase/schema.sql`
3. Run it — this creates all tables, RLS policies, functions, and triggers

### 4. Configure environment variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
NEXT_PUBLIC_APP_URL=https://gazebio.vercel.app
```

### 5. Run locally

```bash
npm run dev
```

Visit `http://localhost:3000`

---

## Deploy to Vercel

1. Push your code to GitHub
2. Import the repo at [vercel.com/new](https://vercel.com/new)
3. Add the environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_APP_URL` → `https://gazebio.vercel.app`
4. Deploy

### Configure Supabase for production

In your Supabase dashboard → **Authentication → URL Configuration**:

- **Site URL**: `https://gazebio.vercel.app`
- **Redirect URLs**: `https://gazebio.vercel.app/auth/callback`

---

## Features

- 🔐 **Auth** — Email/password sign up & login with Supabase Auth
- 🎨 **6 Themes** — Dark Modern, Neon Gamer, Cyberpunk Glow, Soft Aesthetic, Gradient Glass, Minimal Light
- ✏️ **Split Editor** — Real-time live preview as you edit
- 🔗 **Link Manager** — Add, edit, reorder, delete links with optimistic UI
- 📊 **Analytics** — View counts, click tracking per link
- 🌐 **Public Pages** — `gazebio.vercel.app/username` for every user
- 📱 **Mobile-first** — Responsive public profile pages
- ⚡ **Server Actions** — Direct DB mutations, no API boilerplate

---

## Themes

| Theme | Accent | Font |
|-------|--------|------|
| Dark Modern | #00f5c4 | DM Sans |
| Neon Gamer | #00f5c4 | Orbitron |
| Cyberpunk Glow | #ff007f | Orbitron |
| Soft Aesthetic | #c084fc | Playfair Display |
| Gradient Glass | #38bdf8 | Syne |
| Minimal Light | #6c63ff | Syne |

---

## Roadmap

- [ ] Avatar image upload (Supabase Storage)
- [ ] Custom link icons
- [ ] Animated gradient backgrounds
- [ ] Link click analytics chart (daily/weekly)
- [ ] Custom domains
- [ ] Premium themes
- [ ] Remove branding (Pro plan)
- [ ] Social meta preview per link
