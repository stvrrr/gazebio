import Link from 'next/link'
import { GazeWordmark } from '@/components/ui/GazeWordmark'

export default function UsernameNotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 bg-[#070710] px-6 text-center relative overflow-hidden">
      {/* Ambient */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[400px] h-[400px] rounded-full pointer-events-none opacity-20 animate-orb1"
        style={{ background: 'radial-gradient(circle, #00f5c4 0%, transparent 70%)' }}
      />

      <GazeWordmark />

      <div className="relative z-10">
        <p className="font-syne text-6xl font-black text-[#e8eaf6] tracking-tighter">404</p>
        <p className="text-[var(--sub)] text-base mt-2">
          This profile doesn't exist yet.
        </p>
        <p className="text-[var(--sub)] text-sm mt-1">
          Want this username?
        </p>
      </div>

      <div className="flex gap-3 flex-wrap justify-center relative z-10">
        <Link
          href="/signup"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-accent to-[#00c4f5] text-[#020c0a] text-sm font-semibold hover:shadow-[0_0_24px_rgba(0,245,196,0.4)] hover:-translate-y-0.5 transition-all"
        >
          Claim it on Gaze
        </Link>
        <Link
          href="/login"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[var(--glass)] border border-[var(--glass-border)] text-[var(--text)] text-sm font-medium hover:bg-[var(--glass-hover)] transition-all"
        >
          Sign in
        </Link>
      </div>
    </div>
  )
}
