import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getProfileByUsername, getLinks, incrementProfileView } from '@/lib/actions/profile'
import PublicProfile from '@/components/profile/PublicProfile'

interface Props {
  params: { username: string }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const profile = await getProfileByUsername(params.username)
  if (!profile) return { title: 'Not Found' }

  return {
    title: `${profile.display_name} (@${profile.username})`,
    description: profile.bio || `Check out ${profile.display_name}'s links on Gaze.`,
    openGraph: {
      title: `${profile.display_name} · Gaze`,
      description: profile.bio || `${profile.display_name}'s links`,
      url: `https://gazebio.vercel.app/${profile.username}`,
      images: [
        {
          url: `https://gazebio.vercel.app/api/og?username=${profile.username}`,
          width: 1200,
          height: 630,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: `${profile.display_name} · Gaze`,
      description: profile.bio,
      images: [`https://gazebio.vercel.app/api/og?username=${profile.username}`],
    },
  }
}

export default async function PublicProfilePage({ params }: Props) {
  const profile = await getProfileByUsername(params.username)
  if (!profile) notFound()

  const links = await getLinks(profile.id)

  // Fire-and-forget view increment
  incrementProfileView(profile.id).catch(() => {})

  return <PublicProfile profile={profile} links={links} />
}
