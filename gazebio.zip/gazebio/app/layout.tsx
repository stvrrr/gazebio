import type { Metadata, Viewport } from 'next'
import { Syne, DM_Sans, Orbitron, Playfair_Display, JetBrains_Mono } from 'next/font/google'
import { Toaster } from 'react-hot-toast'
import '@/styles/globals.css'

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-syne',
  display: 'swap',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600'],
  style: ['normal', 'italic'],
  variable: '--font-dm-sans',
  display: 'swap',
})

const orbitron = Orbitron({
  subsets: ['latin'],
  weight: ['400', '600', '700', '900'],
  variable: '--font-orbitron',
  display: 'swap',
})

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['400', '600'],
  variable: '--font-playfair',
  display: 'swap',
})

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['300', '400'],
  variable: '--font-jetbrains',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'Gaze — BioLinks',
    template: '%s · Gaze',
  },
  description:
    'Your link. Your identity. Elevated. Build a stunning bio link page in seconds with Gaze.',
  metadataBase: new URL('https://gazebio.vercel.app'),
  openGraph: {
    title: 'Gaze — BioLinks',
    description: 'Your link. Your identity. Elevated.',
    url: 'https://gazebio.vercel.app',
    siteName: 'Gaze',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Gaze — BioLinks',
    description: 'Your link. Your identity. Elevated.',
  },
  icons: {
    icon: '/favicon.svg',
  },
}

export const viewport: Viewport = {
  themeColor: '#070710',
  colorScheme: 'dark',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html
      lang="en"
      className={`${syne.variable} ${dmSans.variable} ${orbitron.variable} ${playfair.variable} ${jetbrains.variable}`}
    >
      <body className="font-dm min-h-screen bg-[#070710] text-[#e8eaf6]">
        {children}
        <Toaster
          position="bottom-center"
          toastOptions={{
            style: {
              background: 'rgba(14,14,28,0.95)',
              border: '1px solid rgba(0,245,196,0.25)',
              color: '#e8eaf6',
              backdropFilter: 'blur(20px)',
              borderRadius: '12px',
              fontSize: '14px',
              fontFamily: 'var(--font-dm-sans), sans-serif',
            },
            success: {
              iconTheme: { primary: '#00f5c4', secondary: '#070710' },
            },
            error: {
              iconTheme: { primary: '#ff4d6d', secondary: '#070710' },
            },
          }}
        />
      </body>
    </html>
  )
}
