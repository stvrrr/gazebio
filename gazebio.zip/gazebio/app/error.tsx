'use client'

import { useEffect } from 'react'
import { GazeWordmark } from '@/components/ui/GazeWordmark'

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 bg-[#070710] px-6 text-center">
      <GazeWordmark />
      <div>
        <p className="font-syne text-3xl font-black text-[#e8eaf6] tracking-tight">Something went wrong</p>
        <p className="text-[var(--sub)] text-sm mt-2 max-w-xs">
          An unexpected error occurred. Try refreshing the page.
        </p>
      </div>
      <button
        onClick={reset}
        className="px-5 py-2.5 rounded-xl bg-[var(--glass)] border border-[var(--glass-border)] text-[var(--text)] text-sm font-medium hover:bg-[var(--glass-hover)] transition-all"
      >
        Try again
      </button>
    </div>
  )
}
