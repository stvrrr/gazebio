import Link from 'next/link'
import { GazeWordmark } from '@/components/ui/GazeWordmark'

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 bg-[#070710] px-6 text-center">
      <GazeWordmark />
      <div>
        <p className="font-syne text-5xl font-black text-[#e8eaf6] tracking-tight mb-2">404</p>
        <p className="text-[#7b7fa3] text-base">This page doesn't exist — or hasn't been created yet.</p>
      </div>
      <Link
        href="/login"
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[rgba(0,245,196,0.1)] border border-[rgba(0,245,196,0.25)] text-[#00f5c4] text-sm font-semibold transition hover:bg-[rgba(0,245,196,0.18)]"
      >
        Go home
      </Link>
    </div>
  )
}
