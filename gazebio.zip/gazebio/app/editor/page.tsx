import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getProfile, getLinks } from '@/lib/actions/profile'
import AppShell from '@/components/layout/AppShell'
import EditorView from '@/components/editor/EditorView'

export const metadata: Metadata = {
  title: 'Editor',
}

export default async function EditorPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const profile = await getProfile()
  if (!profile) redirect('/login')

  const links = await getLinks(profile.id)

  return (
    <AppShell profile={profile} user={user} fullWidth>
      <EditorView profile={profile} links={links} />
    </AppShell>
  )
}
