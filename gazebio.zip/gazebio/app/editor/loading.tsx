export default function EditorLoading() {
  return (
    <div className="flex h-[calc(100vh-60px)] overflow-hidden animate-pulse">
      {/* Left panel skeleton */}
      <div className="w-[380px] flex-shrink-0 border-r border-[var(--glass-border)] p-5 space-y-4">
        <div className="flex gap-4 border-b border-[var(--glass-border)] pb-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-5 w-16 bg-white/[0.06] rounded-md" />
          ))}
        </div>
        <div className="flex flex-col items-center gap-2 pt-4">
          <div className="w-[72px] h-[72px] bg-white/[0.06] rounded-full" />
          <div className="h-3 w-28 bg-white/[0.04] rounded-md" />
        </div>
        {[1, 2, 3].map(i => (
          <div key={i} className="space-y-1.5">
            <div className="h-3 w-20 bg-white/[0.04] rounded-md" />
            <div className="h-10 w-full bg-white/[0.04] rounded-[10px]" />
          </div>
        ))}
      </div>

      {/* Right preview skeleton */}
      <div className="flex-1 bg-black/20 flex flex-col">
        <div className="h-[46px] border-b border-[var(--glass-border)] bg-[var(--glass)]" />
        <div className="flex-1 flex justify-center p-5">
          <div className="w-full max-w-[390px] space-y-4">
            <div className="flex flex-col items-center gap-3 py-8">
              <div className="w-[88px] h-[88px] bg-white/[0.06] rounded-full" />
              <div className="h-6 w-40 bg-white/[0.06] rounded-lg" />
              <div className="h-4 w-28 bg-white/[0.04] rounded-md" />
              <div className="h-4 w-56 bg-white/[0.04] rounded-md" />
            </div>
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-14 w-full bg-white/[0.04] rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
