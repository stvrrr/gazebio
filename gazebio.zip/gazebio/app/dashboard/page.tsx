import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getProfile, getLinks, getProfileStats } from '@/lib/actions/profile'
import AppShell from '@/components/layout/AppShell'
import DashboardView from '@/components/dashboard/DashboardView'

export const metadata: Metadata = {
  title: 'Dashboard',
}

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const profile = await getProfile()
  if (!profile) redirect('/login')

  const [links, stats] = await Promise.all([
    getLinks(profile.id),
    getProfileStats(profile.id),
  ])

  return (
    <AppShell profile={profile} user={user}>
      <DashboardView profile={profile} links={links} stats={stats} />
    </AppShell>
  )
}
