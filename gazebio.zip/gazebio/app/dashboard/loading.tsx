export default function DashboardLoading() {
  return (
    <div className="py-7 space-y-6 animate-pulse">
      {/* Header skeleton */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="h-7 w-56 bg-white/[0.06] rounded-lg" />
          <div className="h-4 w-36 bg-white/[0.04] rounded-md" />
        </div>
        <div className="flex gap-2">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-9 w-24 bg-white/[0.04] rounded-[10px]" />
          ))}
        </div>
      </div>

      {/* Stat cards skeleton */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="glass-card p-6 space-y-3">
            <div className="w-9 h-9 bg-white/[0.06] rounded-[10px]" />
            <div className="h-7 w-20 bg-white/[0.06] rounded-lg" />
            <div className="h-3 w-24 bg-white/[0.04] rounded-md" />
          </div>
        ))}
      </div>

      {/* Bottom grid skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-4">
        <div className="glass-card p-6 space-y-4">
          <div className="h-5 w-36 bg-white/[0.06] rounded-lg" />
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="space-y-2 py-3 border-b border-white/[0.05]">
              <div className="flex justify-between">
                <div className="h-4 w-40 bg-white/[0.04] rounded-md" />
                <div className="h-4 w-12 bg-white/[0.04] rounded-md" />
              </div>
              <div className="h-1 w-full bg-white/[0.04] rounded-full" />
            </div>
          ))}
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="glass-card p-5 h-24" />
          ))}
        </div>
      </div>
    </div>
  )
}
