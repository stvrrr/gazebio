import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const username = searchParams.get('username')

  if (!username || username.length < 2) {
    return NextResponse.json({ available: false, error: 'Too short' })
  }

  if (!/^[a-z0-9_]+$/.test(username)) {
    return NextResponse.json({
      available: false,
      error: 'Only lowercase letters, numbers, and underscores',
    })
  }

  const supabase = createClient()
  const { data } = await supabase
    .from('profiles')
    .select('id')
    .eq('username', username)
    .single()

  return NextResponse.json({ available: !data })
}
