import { ImageResponse } from 'next/og'
import { getProfileByUsername } from '@/lib/actions/profile'

export const runtime = 'edge'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const username = searchParams.get('username') ?? 'gaze'

  let displayName = username
  let bio = 'Check out my links on Gaze.'
  let accent = '#00f5c4'

  try {
    const profile = await getProfileByUsername(username)
    if (profile) {
      displayName = profile.display_name || profile.username
      bio = profile.bio || bio
      accent = profile.accent_color || accent
    }
  } catch {
    // fallback to defaults
  }

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #070710 0%, #0e0e1f 100%)',
          fontFamily: 'sans-serif',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Glow orb */}
        <div
          style={{
            position: 'absolute',
            top: '10%',
            left: '50%',
            transform: 'translateX(-50%)',
            width: 400,
            height: 400,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${accent}25 0%, transparent 70%)`,
          }}
        />

        {/* Gaze logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 32 }}>
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: '50%',
              background: `linear-gradient(135deg, ${accent}, #00c4f5)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <div
              style={{
                width: '42%',
                height: '42%',
                borderRadius: '50%',
                background: '#070710',
              }}
            />
          </div>
          <span
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: '#e8eaf6',
              letterSpacing: '-0.03em',
            }}
          >
            gaze<span style={{ color: accent }}>.</span>
          </span>
        </div>

        {/* Avatar circle */}
        <div
          style={{
            width: 96,
            height: 96,
            borderRadius: '50%',
            background: `${accent}20`,
            border: `3px solid ${accent}50`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 36,
            fontWeight: 800,
            color: accent,
            marginBottom: 20,
            boxShadow: `0 0 40px ${accent}30`,
          }}
        >
          {displayName.slice(0, 1).toUpperCase()}
        </div>

        <div
          style={{
            fontSize: 38,
            fontWeight: 800,
            color: '#e8eaf6',
            letterSpacing: '-0.03em',
            marginBottom: 10,
          }}
        >
          {displayName}
        </div>

        <div
          style={{
            fontSize: 16,
            color: `${accent}`,
            fontFamily: 'monospace',
            marginBottom: 14,
          }}
        >
          @{username}
        </div>

        {bio && (
          <div
            style={{
              fontSize: 18,
              color: '#7b7fa3',
              maxWidth: 520,
              textAlign: 'center',
              lineHeight: 1.5,
            }}
          >
            {bio.length > 100 ? bio.slice(0, 100) + '...' : bio}
          </div>
        )}
      </div>
    ),
    { width: 1200, height: 630 }
  )
}
