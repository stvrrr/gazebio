import type { Metadata } from 'next'
import AuthForm from '@/components/auth/AuthForm'

export const metadata: Metadata = {
  title: 'Create Account',
  description: 'Create your free Gaze bio link page.',
}

export default function SignUpPage() {
  return <AuthForm mode="signup" />
}
